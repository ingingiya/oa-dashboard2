#!/bin/zsh
# 모바일 큐텐 실시간 보기 (맥) — 크롬을 아이폰 모드로 따로 띄웁니다. 더블클릭하면 열립니다.
UA="Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"
URL="${1:-https://m.qoo10.jp/shop/oaworld}"
open -na "Google Chrome" --args --user-data-dir="$HOME/.oa-qoo10-mobile-view" --no-first-run --no-default-browser-check --user-agent="$UA" --window-size=430,932 --app="$URL"
